from dspy_programs.decision_optimizer import optimize_decision_model

class DecisionAgent:

    def __init__(self):
        self.program = optimize_decision_model()

    def run(self, state: dict):

        result = self.program(
            vendor=state["vendor"],
            total=state["total"],
            fraud_score=str(state["fraud_score"]),
            fraud_reason=state["fraud_reason"]
        )

        return {
            **state,
            "decision": result.decision,
            "explanation": result.explanation
        }
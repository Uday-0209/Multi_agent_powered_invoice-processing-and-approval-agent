class NotificationAgent:
    
    def run(self, state: dict):
        if state['decision'] == 'manual_review':
            print("Notify the finance team for manual review.")
        if state["decision"] == "approved":
            print("notify vendor")
            
        return state
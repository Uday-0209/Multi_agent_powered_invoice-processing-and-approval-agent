class ValidationAgent:
    
    def run(self, state):
        total = state["total"]
        
        if not total:
            return {
                **state,
                "validation_status": "invalid"
            }
        return {
            **state,
            "validation_status": "valid"
        }
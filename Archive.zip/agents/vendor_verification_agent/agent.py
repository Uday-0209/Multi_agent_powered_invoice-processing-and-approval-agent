class VendorVerificationAgent:
    
    def run(self, state: dict):
        
        vendor = state['vendor']
        
        trusted_vendors = [
            "ABC Ltd",
            "XYZ Corp"
        ]
        verified = vendor in trusted_vendors
        
        return {
            **state,
            "vendor_verified": verified
        }
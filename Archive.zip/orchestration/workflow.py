from langgraph.graph import StateGraph
from orchestration.state import WorkFlowState

from agents.ocr_agent.agent import OCRAgent
from agents.extraction_agent.agent import ExtractionAgent
from agents.fraud_agent.agent import FraudAgent
from agents.decision_agent.agent import DecisionAgent
from agents.human_review_agent.agent import HumanReviewAgent
from agents.document_intake_agent.agent import DocumentIntakeAgent
from agents.notification_agent.agent import NotificationAgent
from agents.audit_agent.agent import AuditAgent
from agents.validation_agent.agent import ValidationAgent
from agents.classification_agent.agent import ClassificationAgent
from agents.policy_agent.agent import PolicyAgent
from agents.vendor_verification_agent.agent import VendorVerificationAgent


def build_workflow():
    
    graph = StateGraph(WorkFlowState)
    
    ocr = OCRAgent()
    extraction = ExtractionAgent()
    fraud = FraudAgent()
    decision = DecisionAgent()
    human_review = HumanReviewAgent()
    
    graph.add_node('ocr', ocr.run)
    graph.add_node('extraction', extraction.run)
    graph.add_node('fraud', fraud.run)
    graph.add_node('decision', decision.run)
    graph.add_node('human_review', human_review.run)
    graph.add_node("intake", DocumentIntakeAgent
    
    graph.set_entry_point('ocr')
    
    graph.add_edge('ocr', 'extraction')
    graph.add_edge('extraction', 'fraud')
    graph.add_edge('fraud', 'decision')
    graph.add_conditional_edge(
            "decision",
        route_decision,
        {
            "human_review": "human_review",
            "end": "__end__"
        }
    )
    
    return graph.compile()